"""Persistent audit guard. Does not change sys.path or isolation flags."""
import sys,os,json,runpy,hashlib
log,target,*args=sys.argv[1:]
blocked={'isaaclab','isaaclab_physx','isaaclab_ov','isaaclab_arena','isaacsim','omni','carb','pxr'}
def record(**row):
 fd=os.open(log,os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
 os.write(fd,(json.dumps(row,allow_nan=False)+'\n').encode());os.close(fd)
def consumed():
 out={}
 for m in list(sys.modules.values()):
  p=getattr(m,'__file__',None)
  if p and os.path.isfile(p):
   with open(p,'rb') as f:out[p]=hashlib.file_digest(f,'sha256').hexdigest()
 return out
def audit(event,a):
 if event=='import' and (a[0].split('.')[0] in blocked or a[0] in {'yam_arena.scene','yam_arena.actions','yam_arena.inspect_embodiment'}):
  record(event='boundary',module=a[0],isolated=sys.flags.isolated,path=sys.path,consumed_files=consumed(),local_modules={n:getattr(m,'__file__',None) for n,m in sys.modules.items() if '/hydraulic-supported-yam-whole-v4-20261110-0920/' in str(getattr(m,'__file__',''))});os._exit(86)
 if event=='exec' and any(x in blocked for x in a[0].co_filename.replace('\\','/').split('/')):
  record(event='blocked_exec',file=a[0].co_filename);os._exit(86)
 if event in {'os.exec','os.posix_spawn','os.system','os.fork','os.forkpty','subprocess.Popen'}:
  record(event='escape_blocked',kind=event);os._exit(87)
sys.addaudithook(audit)
record(event='guard_installed',isolated=sys.flags.isolated,path=sys.path)
import yam_arena.task_file as tf
original=tf.load
def load(*a,**kw):
 result=original(*a,**kw);record(event='actual_task_constructed',task=str(a[0]),type=type(result).__name__,docs=result.docs);return result
tf.load=load
sys.argv=[target,*args];runpy.run_path(target,run_name='__main__')
