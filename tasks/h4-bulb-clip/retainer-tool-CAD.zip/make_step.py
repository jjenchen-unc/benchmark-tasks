"""Manufacturing geometry in millimetres. Requires the Python OCP bindings."""
from pathlib import Path
from OCP.BRep import BRep_Builder
from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut, BRepAlgoAPI_Fuse
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox, BRepPrimAPI_MakeCylinder, BRepPrimAPI_MakeCone
from OCP.gp import gp_Ax2, gp_Dir, gp_Pnt
from OCP.IFSelect import IFSelect_RetDone
from OCP.STEPControl import STEPControl_AsIs, STEPControl_Writer
from OCP.TopoDS import TopoDS_Compound

def box(x0,y0,z0,x1,y1,z1):
    return BRepPrimAPI_MakeBox(gp_Pnt(x0,y0,z0),gp_Pnt(x1,y1,z1)).Shape()

def axis(origin,direction):
    return gp_Ax2(gp_Pnt(*origin),gp_Dir(*direction))

def cylinder(origin,direction,radius,length):
    return BRepPrimAPI_MakeCylinder(axis(origin,direction),radius,length).Shape()

def cut(a,b):
    return BRepAlgoAPI_Cut(a,b).Shape()

def fuse(a,b):
    return BRepAlgoAPI_Fuse(a,b).Shape()

def collar(negative):
    ring=cut(cylinder((0,0,34),(0,0,1),33,12),cylinder((0,0,33),(0,0,1),28.55,14))
    ring=cut(ring,box(-50,-.20 if negative else -50,30,50,50 if negative else .20,50))
    for x in (-34,34):
        ya,yb=(-5.8,-.2) if negative else (.2,5.8)
        ring=fuse(ring,box(x-3,ya,34,x+3,yb,46))
        # Tap drill in the lower half and a clearance hole in the upper one.
        ring=cut(ring,cylinder((x,-7,40),(0,1,0),1.25 if negative else 1.6,14))
    if negative:
        ring=cut(ring,box(-3.02,-35,37.48,3.02,-30,42.52))
        ring=cut(ring,cylinder((0,-27.4,40),(0,-1,0),1.35,5.8))
        head=BRepPrimAPI_MakeCone(axis((0,-28.4,40),(0,-1,0)),2.35,1.35,1.).Shape()
        ring=cut(ring,head)
    return ring

def shoe():
    shank=box(-3,-93,37.5,3,-30,42.5)
    shank=fuse(shank,box(-1.5,-103,38.5,1.5,-92.5,41.5))
    # Bearing faces at y=-105.20 and x=+0.80 in the gripper frame.
    shank=fuse(shank,box(-1.8,-105.2,38.5,2.8,-101.5,41.5))
    shank=fuse(shank,box(.8,-106.9,38.5,2.8,-105.2,41.5))
    return cut(shank,cylinder((0,-29.9,40),(0,-1,0),1.025,7))

def write(path,shape):
    assert BRepCheck_Analyzer(shape).IsValid(),path
    writer=STEPControl_Writer()
    assert writer.Transfer(shape,STEPControl_AsIs)==IFSelect_RetDone
    assert writer.Write(str(path))==IFSelect_RetDone

if __name__=='__main__':
    out=Path(__file__).resolve().parent
    assembly=TopoDS_Compound()
    builder=BRep_Builder();builder.MakeCompound(assembly)
    for name,part in [('upper_collar',collar(False)),('lower_collar',collar(True)),('steel_shoe',shoe())]:
        write(out/(name+'.step'),part)
        builder.Add(assembly,part)
    write(out/'retainer_tool.step',assembly)
