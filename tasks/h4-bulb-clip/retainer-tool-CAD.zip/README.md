# YAM clip-retainer shoe

The shoe reaches the H4 retainer through the rear access opening while the stock fingers stay behind it. One flat face presses the rear of the wire. The second face supports its outer side while the wire moves past the fixed tab. The two opposite sides are open, allowing the driver to unload and retract.

## Parts and dimensions

All STEP dimensions are millimetres in the YAM left gripper frame. Machine one of each component. The complete assembly STEP has three solids. The three individual files use the same origin.

| Part | Material used for design | Dimensions and finishing |
|---|---|---|
| Upper and lower collar | 6061 aluminium | Bore Ø57.10, outside Ø66, axial width 12. The intended stationary boss measures Ø57.0 in the YAM collision CAD. Two split ears retain the collar. Upper screw holes are Ø3.2 clearance. Tap the lower Ø2.5 pilot holes M3×0.5. |
| Contact shoe and integral stem | Steel | Main stem 6×5, reduced nose 3×3. The two flat wire-bearing faces are 3 wide. Heel is 4.6 across by 3.7 deep, outer wall is 2.0 thick and projects 1.7 ahead of the heel. Keep both inner bearing faces square and ease exposed burrs. |
| Mounting | Two M3×12 clamp screws and one M2.5 retaining screw | Seat the steel tang in the 6.04×5.04 register in the lower collar. Tap the Ø2.05 axial pilot in the tang M2.5×0.45. Fit a flush fastener from the bore side before assembling the split collar. Set retaining screw length from the actual recessed seat and 7 mm pilot depth. |

The shoe reference point is (0, −106, 40) relative to the gripper link origin. The positive axial pressure points along gripper −y and the lateral pressure along gripper −x. In the central clip operation these become station +x and +y. The lower pocket locates the steel tang and transfers transverse load. The stock fingers and their rack still move independently.

## CAD and simulator checks

OpenCascade reimported each STEP and validated every solid. Pairwise solid intersections had zero volume. The machined aluminium and steel parts total 45.87 g before fasteners. The simulator represents the installed accessory with solid clamp envelopes and smooth collision faces. Its estimated mass is 50.06 g. The simulation adds that mass, its first moment and its inertia tensor to the stock gripper. The scorer also checks clearance of the shoe tip.

The design uses the YAM collision CAD for the clamp seat. On a physical arm, verify boss diameter, the available 12 mm axial band, the flush screw seat, connector clearance and clearance over the finger travel before fitting the collar. The clamp, shoe and headlamp have not been fabricated or measured together. The STEP files describe the proposed tooling.

Run `make_step.py` with Python and the OCP bindings to regenerate the assembly and part STEP files. The XML-free collision and mass model is in the task's `src/retainer_tool.py`. The STEP includes screw pilot holes, the clamp split, and the steel tang register.
